# Agent Ground

Agent Ground gives coding agents durable preferences and repository context without pretending generated memory is truth.

## Layers

1. Canonical accepted preferences in `Documents/Agent Ground`.
2. Managed global instruction blocks for Codex and Antigravity.
3. Repository-owned rules, architecture notes, ADRs, and transient checkpoints.
4. Disposable retrieval indexes: CodeGraph, QMD, and selective Graphify.

## Commands

```powershell
python .\scripts\agent_ground.py init C:\path\to\repo
python .\scripts\agent_ground.py status C:\path\to\repo
python .\scripts\agent_ground.py checkpoint C:\path\to\repo --message "Next concrete action"
python .\scripts\agent_ground.py verify C:\path\to\repo --yes
python .\scripts\agent_ground.py sync-preferences
python .\scripts\agent_ground.py doctor
```

`init` preserves existing files and owns only marker-bounded blocks. `verify` refuses dirty scoped source. QMD and Graphify are retrieval aids; they are never authorities.
