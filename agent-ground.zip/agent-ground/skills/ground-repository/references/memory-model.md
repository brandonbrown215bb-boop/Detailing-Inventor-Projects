# Agent Ground Memory Model

## Authorities

| Kind | Authority | Mutation rule |
|---|---|---|
| Required behavior | `AGENTS.md`, nested instructions, accepted global defaults | Change intentionally; never infer silently |
| Personal preference | Agent Ground vault `Preferences/` | Candidate first, then user-approved promotion |
| Repository architecture | Current source plus scoped architecture notes | Source wins; mark notes stale when scoped code changes |
| Decision history | ADRs | Append or supersede; do not rewrite the past |
| Task continuity | `.agents/state/current.md` | Replace freely; never present as durable truth |
| Retrieval | QMD indexes, Graphify graphs, CodeGraph index | Derived and disposable |

## Freshness

`docs/context-manifest.json` binds a document to:

- the Git commit at which it was verified;
- source paths or globs whose changes can invalidate it.

A document is stale when a scoped tracked or untracked path differs from the verification commit. Stale means inspect; it does not mean the document is wholly false.

Architecture notes should describe boundaries, data flow, entry points, and dangerous invariants. They should not narrate every file. High-churn detail belongs in source.

## Promotion

A candidate becomes an accepted preference when:

1. The user states it as a default, or explicitly approves the candidate.
2. Its scope is clear.
3. Conflicts and exceptions are recorded beside it.
4. The synchronized global block is regenerated.

Repeated behavior alone is evidence, not consent.
