---
name: ground-repository
description: Ground new or existing repositories with durable agent rules, Obsidian-compatible architecture notes, task checkpoints, and commit-aware freshness checks. Use when beginning substantial work in a repository, when the user asks an agent to remember project conventions, when AGENTS.md/GEMINI.md or architecture documentation is missing or stale, when resuming interrupted work, or when promoting a repeated preference into durable memory.
---

# Ground Repository

Agent Ground separates rules from recollection. Required behavior lives in agent instruction files; accepted knowledge lives in Markdown; generated indexes stay disposable.

## Start Here

1. Find the Git root. If `.codegraph/` exists, use CodeGraph before grep or manual source wandering.
2. Run:

   ```powershell
   python "$env:PLUGIN_ROOT\scripts\agent_ground.py" status .
   ```

3. Read the repository's instruction chain before editing: root and nested `AGENTS.md`, then `docs/architecture/README.md`, relevant ADRs, and `.agents/state/current.md`.
4. Treat a stale document as a map with a hole in it. Inspect current source before relying on the claim.
5. Continue the requested work. Grounding is support work, not a reason to stall.

## Bootstrap

For a meaningful Git repository that lacks durable context:

```powershell
python "$env:PLUGIN_ROOT\scripts\agent_ground.py" init .
```

The command only creates missing files or updates marker-bounded Agent Ground blocks. It does not replace existing instructions. Do not bootstrap tiny experiments merely to satisfy the framework.

After inspecting and correcting the generated architecture note, verify its source scopes:

```powershell
python "$env:PLUGIN_ROOT\scripts\agent_ground.py" verify . --yes
```

Never verify stale notes unread. The command is an assertion, not a formatting step.

## Durable Memory

Classify before writing:

- Personal preference applying across projects: add a candidate with `record-candidate`; promote it to the canonical vault only after the user accepts it.
- Repository invariant or working convention: root or nested `AGENTS.md`.
- Architectural fact: `docs/architecture/` with a source scope in `docs/context-manifest.json`.
- Decision and its reasons: immutable ADR in `docs/decisions/`.
- Interrupted task state: `.agents/state/current.md`, which is ignored by Git.
- Search embeddings or knowledge graphs: derived caches. Rebuild; never treat as authority.

Read [references/memory-model.md](references/memory-model.md) before changing the classification or freshness machinery.

## Checkpoints

Before a long pause, handoff, or risky context shift:

```powershell
python "$env:PLUGIN_ROOT\scripts\agent_ground.py" checkpoint . --message "Next: ..."
```

The plugin also records branch and working-tree shape before compaction. It cannot infer the human meaning of unfinished work; write the next action explicitly when it matters.

## Retrieval Order

Use the cheapest authority that can answer:

1. Current source and tests.
2. CodeGraph for indexed source structure and call paths.
3. Repository Markdown and ADRs.
4. QMD for cross-note semantic retrieval.
5. Graphify for selective mixed-corpus or cross-repository relationship work.

Do not feed Graphify output back into QMD. That makes a hall of mirrors and then gives it a vector index.

## Automatic Defaults

Apply accepted global preferences without asking again unless the repository contradicts them or the action is costly, unsafe, or hard to reverse. Inspect an established project before importing new-project defaults.

When a repeated preference appears stable, record a candidate:

```powershell
python "$env:PLUGIN_ROOT\scripts\agent_ground.py" record-candidate --text "..." --evidence "..."
```

Candidates are not rules. Promotion remains deliberate.
