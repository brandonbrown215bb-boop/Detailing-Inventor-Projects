#!/usr/bin/env python3
"""Agent Ground: durable repository context with explicit freshness."""

from __future__ import annotations

import argparse
import datetime as dt
import fnmatch
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


AGENTS_START = "<!-- AGENT_GROUND_START -->"
AGENTS_END = "<!-- AGENT_GROUND_END -->"
GLOBAL_START = "<!-- AGENT_GROUND_GLOBAL_START -->"
GLOBAL_END = "<!-- AGENT_GROUND_GLOBAL_END -->"
IGNORE_START = "# AGENT_GROUND_START"
IGNORE_END = "# AGENT_GROUND_END"
MANIFEST_PATH = Path("docs/context-manifest.json")
CHECKPOINT_PATH = Path(".agents/state/current.md")


class GroundError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def run(command: list[str], cwd: Path | None = None, check: bool = True) -> str:
    proc = subprocess.run(
        command,
        cwd=str(cwd) if cwd else None,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if check and proc.returncode:
        detail = proc.stderr.strip() or proc.stdout.strip()
        raise GroundError(f"{' '.join(command)} failed: {detail}")
    return proc.stdout.strip()


def git(root: Path, *args: str, check: bool = True) -> str:
    return run(["git", "-C", str(root), *args], check=check)


def git_commit_exists(root: Path, commit: str) -> bool:
    if not re.fullmatch(r"[0-9a-fA-F]{40}", commit):
        return False
    proc = subprocess.run(
        ["git", "-C", str(root), "cat-file", "-e", f"{commit}^{{commit}}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return proc.returncode == 0


def find_git_root(path: str | Path) -> Path:
    candidate = Path(path).expanduser().resolve()
    if candidate.is_file():
        candidate = candidate.parent
    output = run(["git", "-C", str(candidate), "rev-parse", "--show-toplevel"])
    return Path(output).resolve()


def current_commit(root: Path) -> str:
    value = git(root, "rev-parse", "HEAD", check=False)
    return value if re.fullmatch(r"[0-9a-fA-F]{40}", value) else "UNCOMMITTED"


def current_branch(root: Path) -> str:
    return git(root, "branch", "--show-current", check=False) or "(detached)"


def upsert_block(path: Path, start: str, end: str, body: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    block = f"{start}\n{body.strip()}\n{end}"
    if not path.exists():
        path.write_text(block + "\n", encoding="utf-8")
        return "created"

    original = path.read_text(encoding="utf-8-sig")
    pattern = re.compile(re.escape(start) + r".*?" + re.escape(end), re.DOTALL)
    if pattern.search(original):
        updated = pattern.sub(block, original, count=1)
        action = "unchanged" if updated == original else "updated"
    else:
        updated = original.rstrip() + "\n\n" + block + "\n"
        action = "updated"
    if updated != original:
        path.write_text(updated, encoding="utf-8")
    return action


def write_missing(path: Path, content: str) -> str:
    if path.exists():
        return "preserved"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.rstrip() + "\n", encoding="utf-8")
    return "created"


def repo_contract() -> str:
    return """## Repository Ground

- Read `docs/architecture/README.md`, relevant ADRs under `docs/decisions/`, and `.agents/state/current.md` when present before substantial changes.
- Run Agent Ground `status` before trusting architecture notes. Stale notes are orientation only; current source and tests win.
- If `.codegraph/` exists, use CodeGraph before grep or manual source wandering for code structure and call paths.
- Keep boundaries cohesive and testable. Split by responsibility, not ceremony.
- Preserve unrelated work and generated/source boundaries.
- Update documentation when shipped behavior changes. State limitations plainly.
- Record durable project decisions in ADRs. Keep transient task state out of durable documentation."""


def antigravity_rule() -> str:
    return """---
description: Always-on repository grounding and context freshness
alwaysApply: true
---

@../../AGENTS.md

Before substantial work, inspect `docs/context-manifest.json` and treat architecture notes as stale when their scoped source changed after `verified_at_commit`. Current source and tests are authoritative."""


def detect_scopes(root: Path) -> list[str]:
    scopes: list[str] = []
    for name in ("src", "app", "lib", "packages", "services"):
        if (root / name).is_dir():
            scopes.append(f"{name}/**")
    if scopes:
        return scopes

    root_patterns = []
    extensions = (".py", ".cs", ".fs", ".vb", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".java", ".kt", ".cpp", ".c", ".h")
    for child in root.iterdir():
        if child.is_file() and child.suffix.lower() in extensions:
            root_patterns.append(f"*{child.suffix.lower()}")
    return sorted(set(root_patterns)) or ["src/**"]


def detect_commands(root: Path) -> list[str]:
    commands: list[str] = []
    package = root / "package.json"
    if package.exists():
        try:
            scripts = json.loads(package.read_text(encoding="utf-8")).get("scripts", {})
            for name in ("dev", "test", "build", "lint"):
                if name in scripts:
                    commands.append(f"- `{('npm.cmd' if os.name == 'nt' else 'npm')} run {name}`")
        except (json.JSONDecodeError, OSError):
            pass
    if list(root.glob("*.sln")) or list(root.glob("*.slnx")):
        commands.extend(["- `dotnet build`", "- `dotnet test`"])
    if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists():
        commands.append("- `python -m pytest`")
    if (root / "Cargo.toml").exists():
        commands.extend(["- `cargo build`", "- `cargo test`"])
    if (root / "go.mod").exists():
        commands.append("- `go test ./...`")
    return list(dict.fromkeys(commands)) or ["- Inspect the repository and replace this line with verified commands."]


def architecture_template(root: Path, commit: str, scopes: list[str]) -> str:
    scope_lines = "\n".join(f"  - {scope}" for scope in scopes)
    return f"""---
kind: architecture
verified_at_commit: {commit}
scope:
{scope_lines}
---

# Architecture

> Grounded scaffold. Replace guesses with evidence before marking this document verified.

## Purpose

Describe what this repository does and who or what depends on it.

## Boundaries

Describe the cohesive modules, their responsibilities, and the seams between them. Link to source instead of copying volatile implementation detail.

## Data and Control Flow

Describe the important entry points and the path through the system.

## Invariants and Sharp Edges

Record the facts an agent could easily violate: generated/source boundaries, persistence rules, compatibility constraints, and external integrations.

## Validation

See [[../operations/validation|validation]].
"""


def operations_template(title: str, commands: list[str]) -> str:
    return f"""# {title}

These commands are evidence-backed starting points. Correct this page when the repository disagrees.

{chr(10).join(commands)}
"""


def init_repo(path: str, json_output: bool = False) -> dict[str, Any]:
    root = find_git_root(path)
    commit = current_commit(root)
    scopes = detect_scopes(root)
    actions: dict[str, str] = {}

    actions["AGENTS.md"] = upsert_block(root / "AGENTS.md", AGENTS_START, AGENTS_END, repo_contract())
    actions["GEMINI.md"] = upsert_block(
        root / "GEMINI.md",
        AGENTS_START,
        AGENTS_END,
        "@AGENTS.md\n\nUse the Agent Ground repository contract and current source as authority.",
    )
    actions[".agents/rules/agent-ground.md"] = write_missing(
        root / ".agents/rules/agent-ground.md", antigravity_rule()
    )
    actions["docs/architecture/README.md"] = write_missing(
        root / "docs/architecture/README.md", architecture_template(root, commit, scopes)
    )
    actions["docs/decisions/README.md"] = write_missing(
        root / "docs/decisions/README.md",
        "# Architecture Decisions\n\nCreate numbered ADRs for decisions whose reasons need to survive the implementation.",
    )
    commands = detect_commands(root)
    actions["docs/operations/development.md"] = write_missing(
        root / "docs/operations/development.md", operations_template("Development", commands)
    )
    actions["docs/operations/validation.md"] = write_missing(
        root / "docs/operations/validation.md", operations_template("Validation", commands)
    )
    manifest = {
        "schema_version": 1,
        "documents": [
            {
                "path": "docs/architecture/README.md",
                "scope": scopes,
                "verified_at_commit": commit,
            }
        ],
    }
    actions[str(MANIFEST_PATH)] = write_missing(
        root / MANIFEST_PATH, json.dumps(manifest, indent=2) + "\n"
    )
    actions[".gitignore"] = upsert_block(
        root / ".gitignore",
        IGNORE_START,
        IGNORE_END,
        ".agents/state/\n.obsidian/\n.graphify/\ngraphify-out/\n.qmd/",
    )
    result = {"root": str(root), "commit": commit, "scopes": scopes, "actions": actions}
    emit(result, json_output)
    return result


def path_matches(path: str, scope: str) -> bool:
    normalized = path.replace("\\", "/").lstrip("./")
    pattern = scope.replace("\\", "/").lstrip("./")
    if pattern.endswith("/**"):
        prefix = pattern[:-3].rstrip("/")
        return normalized == prefix or normalized.startswith(prefix + "/")
    if any(char in pattern for char in "*?["):
        return fnmatch.fnmatch(normalized, pattern)
    return normalized == pattern or normalized.startswith(pattern.rstrip("/") + "/")


def changed_paths(root: Path, base: str) -> set[str]:
    changed: set[str] = set()
    if git_commit_exists(root, base):
        for line in git(root, "diff", "--name-only", f"{base}..HEAD", "--", check=False).splitlines():
            if line:
                changed.add(line)
    for args in (
        ("diff", "--name-only", "--"),
        ("diff", "--cached", "--name-only", "--"),
        ("ls-files", "--others", "--exclude-standard"),
    ):
        for line in git(root, *args, check=False).splitlines():
            if line:
                changed.add(line)
    return changed


def load_manifest(root: Path) -> dict[str, Any]:
    path = root / MANIFEST_PATH
    if not path.exists():
        raise GroundError(f"No {MANIFEST_PATH}. Run `agent_ground.py init` first.")
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GroundError(f"Invalid {MANIFEST_PATH}: {exc}") from exc
    if manifest.get("schema_version") != 1 or not isinstance(manifest.get("documents"), list):
        raise GroundError(f"Unsupported {MANIFEST_PATH} schema.")
    return manifest


def status_data(root: Path) -> dict[str, Any]:
    manifest = load_manifest(root)
    docs = []
    for item in manifest["documents"]:
        doc_path = str(item.get("path", ""))
        scopes = [str(value) for value in item.get("scope", [])]
        base = str(item.get("verified_at_commit", "UNCOMMITTED"))
        changes = sorted(path for path in changed_paths(root, base) if any(path_matches(path, scope) for scope in scopes))
        reasons = []
        if not (root / doc_path).exists():
            reasons.append("document missing")
        if base == "UNCOMMITTED":
            reasons.append("no verification commit")
        elif not git_commit_exists(root, base):
            reasons.append("verification commit unavailable")
        if changes:
            reasons.append("scoped source changed")
        docs.append(
            {
                "path": doc_path,
                "fresh": not reasons,
                "verified_at_commit": base,
                "scope": scopes,
                "changed_paths": changes,
                "reasons": reasons,
            }
        )
    stale = sum(not item["fresh"] for item in docs)
    return {
        "root": str(root),
        "branch": current_branch(root),
        "head": current_commit(root),
        "grounded": True,
        "fresh": stale == 0,
        "stale_documents": stale,
        "documents": docs,
    }


def print_status(data: dict[str, Any]) -> None:
    print(f"Agent Ground: {data['root']}")
    print(f"Branch: {data['branch']}  HEAD: {data['head'][:12]}")
    for item in data["documents"]:
        state = "FRESH" if item["fresh"] else "STALE"
        print(f"{state} {item['path']} @ {item['verified_at_commit'][:12]}")
        for reason in item["reasons"]:
            print(f"  - {reason}")
        for path in item["changed_paths"][:12]:
            print(f"  - changed: {path}")
        if len(item["changed_paths"]) > 12:
            print(f"  - and {len(item['changed_paths']) - 12} more")


def status_repo(path: str, json_output: bool = False) -> dict[str, Any]:
    root = find_git_root(path)
    data = status_data(root)
    if json_output:
        print(json.dumps(data, indent=2))
    else:
        print_status(data)
    return data


def verify_repo(path: str, yes: bool, document: str | None, json_output: bool = False) -> dict[str, Any]:
    if not yes:
        raise GroundError("Verification is an assertion. Re-run with --yes after inspecting the document and current source.")
    root = find_git_root(path)
    manifest = load_manifest(root)
    head = current_commit(root)
    if head == "UNCOMMITTED":
        raise GroundError("Cannot anchor verification before the repository has a commit.")

    dirty = changed_paths(root, head)
    selected = []
    for item in manifest["documents"]:
        if document and item.get("path") != document:
            continue
        scopes = [str(value) for value in item.get("scope", [])]
        scoped_dirty = sorted(path for path in dirty if any(path_matches(path, scope) for scope in scopes))
        if scoped_dirty:
            raise GroundError("Cannot verify with uncommitted scoped source: " + ", ".join(scoped_dirty[:8]))
        if not (root / str(item.get("path", ""))).exists():
            raise GroundError(f"Document missing: {item.get('path')}")
        item["verified_at_commit"] = head
        selected.append(str(item["path"]))
    if document and not selected:
        raise GroundError(f"Document is not registered: {document}")
    (root / MANIFEST_PATH).write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    result = {"root": str(root), "verified_at_commit": head, "documents": selected}
    emit(result, json_output)
    return result


def short_status(root: Path, limit: int = 40) -> list[str]:
    lines = git(root, "status", "--short", check=False).splitlines()
    return lines[:limit] + ([f"... and {len(lines) - limit} more"] if len(lines) > limit else [])


def checkpoint_text(root: Path, message: str | None, event: str = "manual") -> str:
    status = short_status(root)
    status_block = "\n".join(f"- `{line}`" for line in status) if status else "- Clean"
    next_action = message.strip() if message else "Reconstruct the next action from the active task; this checkpoint only preserves structural state."
    return f"""# Current Agent Checkpoint

Updated: {now_iso()}
Event: {event}
Branch: {current_branch(root)}
HEAD: {current_commit(root)}

## Next Action

{next_action}

## Working Tree

{status_block}

## Resume

Read the instruction chain, run Agent Ground `status`, inspect current source for stale scopes, then continue from the next action.
"""


def checkpoint_repo(path: str, message: str | None, event: str = "manual") -> dict[str, Any]:
    root = find_git_root(path)
    target = root / CHECKPOINT_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(checkpoint_text(root, message, event), encoding="utf-8")
    result = {"root": str(root), "checkpoint": str(target), "event": event}
    print(json.dumps(result, indent=2))
    return result


def default_vault() -> Path:
    configured = os.environ.get("AGENT_GROUND_HOME")
    return Path(configured).expanduser() if configured else Path.home() / "Documents" / "Agent Ground"


def strip_frontmatter(text: str) -> str:
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) == 3:
            return parts[2].strip()
    return text.strip()


def sync_preferences(vault: Path, codex_path: Path, gemini_path: Path, dry_run: bool) -> dict[str, Any]:
    source = vault / "Preferences" / "Defaults.md"
    if not source.exists():
        raise GroundError(f"Canonical preferences not found: {source}")
    accepted = strip_frontmatter(source.read_text(encoding="utf-8"))
    body = (
        "## Accepted Personal Defaults\n\n"
        "These are defaults, not guesses. Apply them without re-asking unless the repository conflicts, "
        "the scope is unclear, or the action is costly, unsafe, or hard to reverse.\n\n"
        f"{accepted}\n\n"
        f"Canonical source: `{source}`\n"
        "New observations go to the Agent Ground Inbox as candidates; never promote them silently."
    )
    if dry_run:
        result = {"dry_run": True, "source": str(source), "targets": [str(codex_path), str(gemini_path)]}
    else:
        result = {
            "dry_run": False,
            "source": str(source),
            "codex": upsert_block(codex_path, GLOBAL_START, GLOBAL_END, body),
            "gemini": upsert_block(gemini_path, GLOBAL_START, GLOBAL_END, body),
        }
    print(json.dumps(result, indent=2))
    return result


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:48] or "candidate"


def record_candidate(text: str, evidence: str | None, vault: Path, repo: str | None) -> Path:
    inbox = vault / "Inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    target = inbox / f"{stamp}-{slugify(text)}.md"
    content = f"""---
kind: preference-candidate
status: candidate
created: {now_iso()}
---

# Candidate

{text.strip()}

## Scope

{repo or "Cross-project; scope still needs confirmation."}

## Evidence

{evidence or "Observed during work; ask before promotion."}

## Promotion Check

- [ ] User accepted this as a default
- [ ] Scope and exceptions are clear
- [ ] `Preferences/Defaults.md` updated
- [ ] Global agent blocks synchronized
"""
    target.write_text(content, encoding="utf-8")
    print(str(target))
    return target


def hook_input() -> dict[str, Any]:
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def hook_session_start(payload: dict[str, Any]) -> None:
    cwd = payload.get("cwd") or os.getcwd()
    try:
        root = find_git_root(cwd)
    except GroundError:
        return
    if not (root / MANIFEST_PATH).exists():
        return
    try:
        data = status_data(root)
    except GroundError:
        return
    checkpoint = root / CHECKPOINT_PATH
    checkpoint_text_value = ""
    if checkpoint.exists():
        checkpoint_text_value = checkpoint.read_text(encoding="utf-8", errors="replace")[:2500]
    stale_lines = []
    for item in data["documents"]:
        if not item["fresh"]:
            stale_lines.append(f"- {item['path']}: {', '.join(item['reasons'])}")
    freshness = "\n".join(stale_lines) if stale_lines else "- Registered context documents are fresh."
    context = f"""Agent Ground is active for `{root}`.
Follow the repository instruction chain. Current source and tests are authoritative.
Freshness:
{freshness}
{"Checkpoint:" + chr(10) + checkpoint_text_value if checkpoint_text_value else "No task checkpoint exists."}
"""
    print(
        json.dumps(
            {
                "hookSpecificOutput": {
                    "hookEventName": "SessionStart",
                    "additionalContext": context,
                }
            }
        )
    )


def hook_pre_compact(payload: dict[str, Any]) -> None:
    cwd = payload.get("cwd") or os.getcwd()
    try:
        root = find_git_root(cwd)
    except GroundError:
        return
    if not (root / MANIFEST_PATH).exists():
        return
    target = root / CHECKPOINT_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    prior = ""
    if target.exists():
        old = target.read_text(encoding="utf-8", errors="replace")
        match = re.search(r"## Next Action\s+(.*?)(?=\n## |\Z)", old, re.DOTALL)
        prior = match.group(1).strip() if match else ""
    target.write_text(checkpoint_text(root, prior or None, "pre-compact"), encoding="utf-8")


def doctor() -> dict[str, Any]:
    tools = {}
    for name in ("git", "qmd", "graphify", "codegraph", "agy", "obsidian"):
        tools[name] = shutil.which(name)
    result = {"vault": str(default_vault()), "tools": tools}
    print(json.dumps(result, indent=2))
    return result


def emit(value: dict[str, Any], as_json: bool) -> None:
    if as_json:
        print(json.dumps(value, indent=2))
        return
    if "actions" in value:
        print(f"Grounded {value['root']}")
        for path, action in value["actions"].items():
            print(f"{action.upper():9} {path}")
    else:
        print(json.dumps(value, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    init_cmd = sub.add_parser("init", help="Add non-destructive repository grounding.")
    init_cmd.add_argument("path", nargs="?", default=".")
    init_cmd.add_argument("--json", action="store_true")

    status_cmd = sub.add_parser("status", help="Report document freshness.")
    status_cmd.add_argument("path", nargs="?", default=".")
    status_cmd.add_argument("--json", action="store_true")

    verify_cmd = sub.add_parser("verify", help="Anchor inspected documents to current HEAD.")
    verify_cmd.add_argument("path", nargs="?", default=".")
    verify_cmd.add_argument("--document")
    verify_cmd.add_argument("--yes", action="store_true")
    verify_cmd.add_argument("--json", action="store_true")

    checkpoint_cmd = sub.add_parser("checkpoint", help="Save transient task continuity.")
    checkpoint_cmd.add_argument("path", nargs="?", default=".")
    checkpoint_cmd.add_argument("--message")

    sync_cmd = sub.add_parser("sync-preferences", help="Synchronize canonical accepted defaults.")
    sync_cmd.add_argument("--vault", type=Path, default=default_vault())
    sync_cmd.add_argument("--codex", type=Path, default=Path.home() / ".codex" / "AGENTS.md")
    sync_cmd.add_argument("--gemini", type=Path, default=Path.home() / ".gemini" / "GEMINI.md")
    sync_cmd.add_argument("--dry-run", action="store_true")

    candidate_cmd = sub.add_parser("record-candidate", help="Record a preference candidate without promoting it.")
    candidate_cmd.add_argument("--text", required=True)
    candidate_cmd.add_argument("--evidence")
    candidate_cmd.add_argument("--repo")
    candidate_cmd.add_argument("--vault", type=Path, default=default_vault())

    hook_cmd = sub.add_parser("hook", help="Internal lifecycle hook entry point.")
    hook_cmd.add_argument("event", choices=("session-start", "pre-compact"))

    sub.add_parser("doctor", help="Report the local retrieval toolchain.")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "init":
            init_repo(args.path, args.json)
        elif args.command == "status":
            status_repo(args.path, args.json)
        elif args.command == "verify":
            verify_repo(args.path, args.yes, args.document, args.json)
        elif args.command == "checkpoint":
            checkpoint_repo(args.path, args.message)
        elif args.command == "sync-preferences":
            sync_preferences(args.vault, args.codex, args.gemini, args.dry_run)
        elif args.command == "record-candidate":
            record_candidate(args.text, args.evidence, args.vault, args.repo)
        elif args.command == "hook":
            payload = hook_input()
            if args.event == "session-start":
                hook_session_start(payload)
            else:
                hook_pre_compact(payload)
        elif args.command == "doctor":
            doctor()
        return 0
    except GroundError as exc:
        print(f"agent-ground: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
