@echo off
set "QMD_CONFIG_DIR=C:\Users\brand\Documents\Agent Ground\.qmd\config"
set "XDG_CACHE_HOME=C:\Users\brand\Documents\Agent Ground\.qmd\cache"
call "C:\Users\brand\AppData\Roaming\npm\qmd.cmd" %*
