# Projects

This is an index, not a mirror.

Each substantial repository keeps its own:

- `AGENTS.md` and `GEMINI.md`
- `docs/architecture/`
- `docs/decisions/`
- `docs/operations/`
- `docs/context-manifest.json`
- ignored `.agents/state/current.md`

Add links here when a cross-project map is genuinely useful. Do not copy repository facts into this vault merely to make the graph look busy.
