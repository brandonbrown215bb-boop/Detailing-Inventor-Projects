---
kind: decision
status: proposed
date:
---

# ADR-NNN: Decision

## Context

What forced a choice?

## Decision

What did we choose?

## Consequences

What becomes easier, harder, or deliberately impossible?

## Supersedes

Link an older ADR when applicable. Do not rewrite it.
