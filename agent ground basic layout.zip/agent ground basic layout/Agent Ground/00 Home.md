# Agent Ground

One place for accepted cross-project preferences. Repositories keep their own facts.

## Start

- [[Preferences/Defaults|Accepted defaults]]
- [[Preferences/Memory Policy|Memory policy]]
- [[Projects/README|Project index]]
- [[Inbox/README|Preference candidates]]

## Authority

Current source and tests outrank architecture notes. Repository instructions outrank global defaults. Accepted preferences outrank inferred habits.

Search indexes and generated graphs are disposable. The Markdown remains.
