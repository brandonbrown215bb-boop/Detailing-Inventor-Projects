@echo off
start "" "C:\Users\brand\AppData\Local\Programs\Obsidian\Obsidian.exe" "C:\Users\brand\Documents\Agent Ground"
