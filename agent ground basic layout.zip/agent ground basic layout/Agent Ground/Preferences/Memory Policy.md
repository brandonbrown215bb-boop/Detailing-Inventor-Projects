---
kind: policy
status: accepted
updated: 2026-07-30
---

# Memory Policy

## Store

- Stable personal defaults with their scope and exceptions.
- Repository conventions in the repository's instruction chain.
- Architecture claims beside the code they describe, with a verification commit and source scope.
- Decisions as ADRs with context and reasons.

## Do Not Store as Truth

- A preference inferred from one task.
- Generated summaries without provenance.
- Search results or graph output.
- Transient branch state in durable documentation.
- Secrets, tokens, credentials, or sensitive research material.

## Promotion

New observations enter [[../Inbox/README|Inbox]] as candidates. A candidate becomes accepted only when its scope is clear and the user has stated or approved it as a default.

When accepted defaults change, synchronize the marker-bounded global Codex and Antigravity blocks. Do not hand-edit generated copies.

## Freshness

Repository documents registered in `docs/context-manifest.json` name the source paths they describe and the Git commit at which they were verified. A later scoped change makes the note stale. Stale means inspect the current source before relying on the note.
