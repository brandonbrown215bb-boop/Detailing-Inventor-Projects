---
kind: accepted-preferences
status: accepted
scope: cross-project
updated: 2026-07-30
---

### Engineering

- Favor cohesive, testable modules with explicit boundaries. Split by responsibility, not ceremony.
- Inspect an established project before applying new-project defaults. Existing architecture and local instructions win.
- Preserve unrelated work. Do not reset, clean, or broadly rewrite a working tree to make a task easier.
- Keep generated artifacts separate from source and exclude them from commits unless they are intentional deliverables.
- Validate changes in proportion to risk. Report what was verified and what still requires the target environment.
- For repositories with `.codegraph/`, use CodeGraph first for source structure and call-path investigation.

### Product and Interface

- For a new interface, begin with a coherent dark theme unless the brand, platform, or product context calls for something else.
- Make the next action obvious, preserve interruption state, and show progress. Avoid workflows that punish attention shifts.
- Prefer local-first tools and storage when cloud coordination is not part of the product's purpose.
- Avoid generic generated-looking interfaces. Give the product a deliberate visual character while keeping it usable.

### Documentation and Memory

- Keep documentation aligned with shipped behavior. State unimplemented features, uncertain claims, and environment limits plainly.
- Repository facts stay with the repository. Cross-project preferences stay in this vault.
- Architecture notes describe boundaries, flows, invariants, and entry points; volatile implementation detail stays in source.
- Treat task checkpoints as disposable continuity, not permanent memory.
- Treat QMD, Graphify, and CodeGraph data as rebuildable indexes, never as sources of truth.
- Act on accepted preferences without asking again unless they conflict with the repository or make an action costly, unsafe, or hard to reverse.
