@echo off
python "C:\Users\brand\.agents\plugins\plugins\agent-ground\scripts\agent_ground.py" %*
