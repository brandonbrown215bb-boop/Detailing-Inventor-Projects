# Preference Candidates

Agents may write one candidate note per possible durable preference. Candidates do not affect behavior.

Promote only after confirming:

- the user wants it as a default;
- its scope and exceptions are clear;
- it does not conflict with a more specific repository rule.

After promotion, update `Preferences/Defaults.md`, synchronize the global blocks, and archive or remove the candidate.
